//
//  ViewController.swift
//  iOS Project2
//
//  Created by Joanna Lin on 3/7/22.
//

import UIKit

class ViewController: UIViewController {

    var titleName = UILabel()
    var cafeSign = UIImageView()
    var inputItem = UITextField()
    var inputQuantity = UITextField()
    var displayItem = UITextView()
    var button = UIButton()
    @objc var pressed = false
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        // Do any additional setup after loading the view.
        
        titleName.text = "Mr. Bean's Cafe"
        titleName.textColor = .black
        titleName.font = .systemFont(ofSize: 30, weight: .bold)
        titleName.textColor = .brown
        titleName.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(titleName)
        
        cafeSign.image = UIImage(named:"cafe")
        cafeSign.contentMode = .scaleAspectFill
        cafeSign.clipsToBounds = true
        cafeSign.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(cafeSign)
        
        inputItem.placeholder = "Item"
        inputItem.textColor = .black
        inputItem.font = .systemFont(ofSize: 15)
        inputItem.backgroundColor = UIColor(red: 0.93, green: 0.79, blue: 0.69, alpha: 1.0)
        inputItem.adjustsFontSizeToFitWidth = true
        inputItem.layer.cornerRadius = 10
        inputItem.textAlignment = .justified
        inputItem.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(inputItem)
        
        inputQuantity.placeholder = "Quantity"
        inputQuantity.textColor = .black
        inputQuantity.font = .systemFont(ofSize: 15)
        inputQuantity.backgroundColor = UIColor(red: 0.93, green: 0.79, blue: 0.69, alpha: 1.0)
        inputQuantity.adjustsFontSizeToFitWidth = true
        inputQuantity.layer.cornerRadius = 10
        inputQuantity.textAlignment = .justified
        inputQuantity.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(inputQuantity)
        
        button.setTitle("Order", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .brown
        button.layer.cornerRadius = 10
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(buttonpressed), for: .touchUpInside)
        view.addSubview(button)
        
        
        displayItem.backgroundColor = UIColor.lightGray
        displayItem.font = .systemFont(ofSize: 15)
        displayItem.layer.cornerRadius = 10
        displayItem.textColor = .white
        displayItem.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(displayItem)
        
        
        setupConstraints()
    }
    
    @objc func buttonpressed(){
        let item: String? = inputItem.text
        let quantity: String? = inputQuantity.text
        if let _ = item{
            displayItem.text += item ?? ""
            displayItem.text += " (" 
            displayItem.text += quantity ?? ""
            displayItem.text += ") \n"
        }

            
    }
    
    func setupConstraints(){
        //For the image
        NSLayoutConstraint.activate([
            cafeSign.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant:20),
            cafeSign.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            cafeSign.widthAnchor.constraint(equalToConstant: 300),
            cafeSign.heightAnchor.constraint(equalToConstant: 300)])
        
        //For the title
        NSLayoutConstraint.activate([
            titleName.topAnchor.constraint(equalTo: cafeSign.bottomAnchor, constant: 30),
            titleName.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            ])
        
        //For input item field
        NSLayoutConstraint.activate([
            inputItem.topAnchor.constraint(equalTo: titleName.bottomAnchor, constant: 30),
            inputItem.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            inputItem.widthAnchor.constraint(equalToConstant: 300),
            inputItem.heightAnchor.constraint(equalToConstant: 50)])
        
        //For input quantity field
        NSLayoutConstraint.activate([
            inputQuantity.topAnchor.constraint(equalTo: inputItem.bottomAnchor, constant: 10),
            inputQuantity.leadingAnchor.constraint(equalTo: inputItem.leadingAnchor),
            inputQuantity.widthAnchor.constraint(equalToConstant: 225),
            inputQuantity.heightAnchor.constraint(equalToConstant: 50)])
        
        //For the button
        NSLayoutConstraint.activate([
            button.topAnchor.constraint(equalTo: inputQuantity.topAnchor),
            button.trailingAnchor.constraint(equalTo: inputItem.trailingAnchor),
            button.bottomAnchor.constraint(equalTo: inputQuantity.bottomAnchor),
            button.widthAnchor.constraint(equalToConstant: 70),
            button.heightAnchor.constraint(equalToConstant: 50)])
        
        //For the display field
        NSLayoutConstraint.activate([
            displayItem.topAnchor.constraint(equalTo: inputQuantity.bottomAnchor, constant: 10),
            displayItem.leadingAnchor.constraint(equalTo: inputQuantity.leadingAnchor),
            displayItem.trailingAnchor.constraint(equalTo: inputItem.trailingAnchor),
            displayItem.widthAnchor.constraint(equalToConstant: 300),
            displayItem.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)])
        
        
        
        
        
        
        
        
        
    }


}

