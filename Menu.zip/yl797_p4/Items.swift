//
//  Items.swift
//  yl797_p4
//
//  Created by Joanna Lin on 3/22/22.
//

import Foundation
enum ItemCat: Equatable {
    case cold
    case hot
    case hfood
    case pastry
    case chdrink
    case others
    case beans
    case merchandise
    case soda
    case water
}

class Items {
    var name: String
    var seasonal: Bool
    var itemType: ItemCat

    init(name: String, itemType: ItemCat, isSeasonal: Bool) {
        self.name = name
        self.seasonal = isSeasonal
        self.itemType = itemType
    }

    func getType() -> String {
        switch itemType {
        case .cold:
            return "Cold Drink"
        case .hot:
            return "Hot Drink"
        case .hfood:
            return "Hot Food"
        case .pastry:
            return "Pastry"
        case .chdrink:
            return "Cold/Hot Drink"
        case .others:
            return "Others"
        case .beans:
            return "Coffee Beans"
        case .merchandise:
            return "Merchandise"
        case .soda:
            return "Soda"
        case .water:
            return "Water"
        }
    }
}
