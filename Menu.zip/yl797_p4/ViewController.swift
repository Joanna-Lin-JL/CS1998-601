//
//  ViewController.swift
//  yl797_p4
//
//  Created by Joanna Lin on 3/22/22.
//

import UIKit


class ViewController: UIViewController {
    
    var tableView = UITableView()
    var colView = UICollectionView(frame: .zero, collectionViewLayout: {
       let flowLayout = UICollectionViewFlowLayout()
        flowLayout.estimatedItemSize = UICollectionViewFlowLayout.automaticSize
        flowLayout.scrollDirection = .horizontal
        return flowLayout
    }())
    
    let reuseIdentifier = "ItemCellReuse"
    let filterreuse = "FilterCellReuse"
    let cellHeight: CGFloat = 50
    let allMembers = [String]()
    var selectedItems = [Items]()
    
    let cold = ItemSelector (filter: .cold)
    let hot = ItemSelector (filter: .hot)
    let hfood = ItemSelector (filter: .hfood)
    let pastry = ItemSelector (filter: .pastry)
    let chdrink = ItemSelector (filter: .chdrink)
    let beans = ItemSelector (filter: .beans)
    let merchandise = ItemSelector (filter: .merchandise)
    let others = ItemSelector (filter: .others)
    let soda = ItemSelector (filter: .soda)
    let water = ItemSelector (filter: .water)
    var activeFilters: [ItemSelector] = []
    var filters: [ItemSelector] = []
    var menu: [Items] = []

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Cafe Menu"
        
        view.backgroundColor = .brown
        
        let vFrapp = Items (name: "Vanilla Frappuccino", itemType: .cold, isSeasonal: false)
        let cFrapp = Items (name: "Caramel Frappuccino", itemType: .cold, isSeasonal: false)
        let pmFrapp = Items (name: "Peppermint Mocha Frappuccino", itemType: .cold, isSeasonal: false)
        let latte = Items (name: "Latte", itemType: .chdrink, isSeasonal: false)
        let psl = Items (name: "Pumpkin Spiced Latte", itemType: .hot, isSeasonal: true)
        let choco = Items (name: "Chocolate Croissant", itemType: .pastry, isSeasonal: false)
        let ss = Items (name: "Sausage Sandwich", itemType: .hfood, isSeasonal: false)
        let reindeer = Items (name: "Reindeer Cakepop", itemType: .pastry, isSeasonal: true)
        let xmas = Items (name: "Christmas Coffee Beans", itemType: .beans, isSeasonal: false)
        let cali = Items (name: "California Cup", itemType: .merchandise, isSeasonal: false)
        let chair = Items (name: "High Chairs", itemType: .others, isSeasonal: false)
        
        menu = [vFrapp, cFrapp, pmFrapp, latte, psl, choco, ss, reindeer, xmas, cali, chair]
        filters = [cold, hot, hfood, pastry, chdrink, beans, merchandise, others, soda, water]
        activeFilters = []
        selectedItems = menu
        
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(TableViewCell.self, forCellReuseIdentifier: reuseIdentifier)
        view.addSubview(tableView)
        
        colView.translatesAutoresizingMaskIntoConstraints = false
        colView.dataSource = self
        colView.delegate = self
        colView.allowsMultipleSelection = true
        colView.register(FilterCollectionViewCell.self, forCellWithReuseIdentifier: filterreuse)
        view.addSubview(colView)
        
        setupConstraints()
    }
    
    
    func setupConstraints() {
        // Setup the constraints for our views
        NSLayoutConstraint.activate([
            colView.leadingAnchor.constraint(equalTo: tableView.leadingAnchor),
            colView.trailingAnchor.constraint(equalTo: tableView.trailingAnchor),
            colView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            colView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 50),
            
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.topAnchor.constraint(equalTo: colView.bottomAnchor, constant: 20),
            tableView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
        ])
    }
}



extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return selectedItems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as? TableViewCell {
            let i = selectedItems[indexPath.row]
            cell.configure(items: i)
            cell.selectionStyle = .none
            return cell
        } else {
            return UITableViewCell()
        }
    }
}



extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
}


extension ViewController: UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView,
                        didSelectItemAt indexPath: IndexPath) {
        let chosen = filters[indexPath.row]

            activeFilters.append(chosen)
            chosen.active = true
        
        selectedItems = menu.filter({ foodItem in
            for af in activeFilters {
                if (foodItem.getType() == af.getFilterType()){
                    return true
                }
            }
            return false
        })
        
        tableView.reloadData()
    }
    
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//        return CGSize(width: 50, height: 50)
//    }
//
    func collectionView(_ collectionView: UICollectionView,
                        didDeselectItemAt indexPath: IndexPath) {
        
        let chosen = filters[indexPath.row]
        
        if chosen.active {
            chosen.active = false
            activeFilters = activeFilters.filter { filter in
                return filter.active
            }
        }

        
        selectedItems = menu.filter({ foodItem in
            for af in activeFilters {
                if (foodItem.getType() == af.getFilterType()){
                    return true
                }
            }
            return false
        })
        
        tableView.reloadData()
    }

    // Perform some action upon selecting an item
}


extension ViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return filters.count
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: filterreuse, for: indexPath) as! FilterCollectionViewCell
        let i = filters[indexPath.row]
        
        
        cell.configure(filter: i)
         cell.backgroundColor = .darkGray

        return cell
    }
}


