//
//  CollectionViewCell.swift
//  yl797_p4
//
//  Created by Joanna Lin on 3/22/22.
//

import UIKit

class FilterCollectionViewCell: UICollectionViewCell {
    var categoryLabel = UILabel()
    
    override var isSelected: Bool {
        didSet {
            layer.borderWidth = isSelected ? 2 : 0
            if isSelected {
                backgroundColor = .purple
            } else {
                backgroundColor = .darkGray
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        layer.borderColor = UIColor.black.cgColor
        layer.cornerRadius = 10
        
        categoryLabel.font = .systemFont(ofSize: 15)
        categoryLabel.textColor = .white
        categoryLabel.textAlignment = .center
        categoryLabel.adjustsFontSizeToFitWidth = true
        
        categoryLabel.translatesAutoresizingMaskIntoConstraints = false
        addSubview(categoryLabel)
        NSLayoutConstraint.activate([
            categoryLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 15),
            categoryLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -15),
            categoryLabel.topAnchor.constraint(equalTo: topAnchor, constant: 15 / 2),
            categoryLabel.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -15 / 2)
        ])
    }
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func configure(filter: ItemSelector) {
        categoryLabel.text = filter.getFilterType()
    }
}
