//
//  TableViewCell.swift
//  yl797_p4
//
//  Created by Joanna Lin on 3/22/22.
//

import UIKit

class TableViewCell: UITableViewCell {

    var nameLabel = UILabel()
       var typeLabel = UILabel()
       var seasonalLabel = UILabel()

       override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
           super.init(style: style, reuseIdentifier: reuseIdentifier)

           nameLabel.font = .systemFont(ofSize: 20, weight: .bold)
           nameLabel.translatesAutoresizingMaskIntoConstraints = false
           contentView.addSubview(nameLabel)

           typeLabel.font = .systemFont(ofSize: 15)
           typeLabel.translatesAutoresizingMaskIntoConstraints = false
           contentView.addSubview(typeLabel)

           seasonalLabel.font = .systemFont(ofSize: 15)
           seasonalLabel.translatesAutoresizingMaskIntoConstraints = false
           contentView.addSubview(seasonalLabel)

           setupConstraints()
       }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
       func configure(items: Items) {
           nameLabel.text = items.name
           typeLabel.text = items.getType()
           if items.seasonal {
               seasonalLabel.text = "seasonal"
           }
           else {
               seasonalLabel.text = "year-round"
           }
       }

       func setupConstraints() {
           let padding: CGFloat = 8
           let labelHeight: CGFloat = 20

           NSLayoutConstraint.activate([
               nameLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: padding),
               nameLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: padding),
               nameLabel.heightAnchor.constraint(equalToConstant: labelHeight)
           ])
           NSLayoutConstraint.activate([
               typeLabel.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
               typeLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor),
               typeLabel.heightAnchor.constraint(equalToConstant: labelHeight)
           ])
           NSLayoutConstraint.activate([
            seasonalLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -5),
            seasonalLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor),
            seasonalLabel.heightAnchor.constraint(equalToConstant: labelHeight)
           ])
       }

}
