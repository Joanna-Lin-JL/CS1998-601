//
//  ItemSelector.swift
//  yl797_p4
//
//  Created by Joanna Lin on 3/22/22.
//

import Foundation
enum FilterCat: Equatable{
    case cold
    case hot
    case hfood
    case pastry
    case chdrink
    case beans
    case merchandise
    case others
    case soda
    case water
}

class ItemSelector {

    
    var filter: FilterCat
    var active: Bool
//    var name: String
//    var seasonal: Bool
//    var itemType: ItemCat

//    init(name: String, itemType: ItemCat, isSeasonal: Bool) {
//        self.name = name
//        self.seasonal = isSeasonal
//        self.itemType = itemType
//    }
    init (filter: FilterCat){
        self.filter = filter
        self.active = false
    }

    func getFilterType() -> String {
        switch filter {
        case .cold:
            return "Cold Drink"
        case .hot:
            return "Hot Drink"
        case .hfood:
            return "Hot Food"
        case .pastry:
            return "Pastry"
        case .chdrink:
            return "Cold/Hot Drink"
        case .beans:
            return "Coffee Beans"
        case .merchandise:
            return "Merchandise"
        case .others:
            return "Others"
        case .soda:
            return "Soda"
        case .water:
            return "Water"
        
        }
    }
}

