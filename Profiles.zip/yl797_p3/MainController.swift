//
//  MainController.swift
//  yl797_p3
//
//  Created by Joanna Lin on 3/16/22.
//

import UIKit
//import XCTest

protocol VCProtocol {

    //var someVariable: Int { get }
    
    func updateSave(nameVal: String?, aboutVal: String?, portfolioVal: String?, yearVal : String?)
    //func updateBack()
    func updateName(nameV : String)
    func updatePortfolio(portfolioV : String)
    func updateYear(yearV : String)
    func updateAbout(aboutV : String)
    func viewDidLoad()
    func updatePic(filename: String?)
    func picPressed()
    func profilePressed()
    //func presentProfile()
    //func presentPic()

}

class MainController: UIViewController, VCProtocol {

    
    var name = UILabel()
    var portfolio = UILabel()
    var myProfile = UILabel()
    var avatar = UIButton ()
    var yearTitle = UILabel()
    var year = UITextView ()
    var about = UITextView ()
    var displayAbout = UILabel ()
    var editProfile = UIButton()
//    var profileIndex = 0
//    var picIndex = 0

        
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        name.text = "Default"
        name.textColor = .brown
        name.font = .systemFont(ofSize: 45, weight: .semibold)
        name.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(name)
        
        portfolio.textColor = .lightGray
        portfolio.font = .systemFont(ofSize: 17)
        portfolio.text = "Default"
        portfolio.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(portfolio)
        
        myProfile.text = "My Profile"
        myProfile.textColor = .brown
        myProfile.font = .systemFont(ofSize: 20, weight: .bold)
        myProfile.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(myProfile)
        
        avatar.setImage(UIImage(named:"Image"), for: .normal)
        avatar.addTarget(self, action: #selector(picPressed), for: .touchUpInside)
        avatar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(avatar)
        
        yearTitle.text = "Year"
        yearTitle.textColor = .brown
        yearTitle.font = .systemFont(ofSize: 15, weight: .semibold)
        yearTitle.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(yearTitle)

        year.textColor = .black
        year.font = .systemFont(ofSize: 10)
        year.layer.cornerRadius = 10
        year.backgroundColor = UIColor(red: 0.93, green: 0.79, blue: 0.69, alpha: 1.0)
        year.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(year)
        
        about.textColor = .black
        about.font = .systemFont(ofSize: 10)
        about.layer.cornerRadius = 10
        about.backgroundColor = UIColor(red: 0.93, green: 0.79, blue: 0.69, alpha: 1.0)
        about.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(about)
        
        displayAbout.text = "About"
        displayAbout.font = .systemFont(ofSize: 15, weight: .semibold)
        displayAbout.textColor = .brown
        displayAbout.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(displayAbout)
        
        editProfile.setTitle("Edit My Profile", for: .normal)
        editProfile.setTitleColor(.brown, for: .normal)
        editProfile.addTarget(self, action: #selector(profilePressed), for: .touchUpInside)
        editProfile.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(editProfile)
       
            setupConstraints()
        }
        

        func setupConstraints(){
            NSLayoutConstraint.activate([
                myProfile.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant:-25),
                myProfile.centerXAnchor.constraint(equalTo: view.centerXAnchor)])
                
            NSLayoutConstraint.activate([
                avatar.topAnchor.constraint(equalTo: myProfile.bottomAnchor, constant: 10),
                avatar.centerXAnchor.constraint(equalTo: view.centerXAnchor),
                avatar.widthAnchor.constraint(equalToConstant: 250),
                avatar.heightAnchor.constraint(equalToConstant: 250)])
                
            NSLayoutConstraint.activate([
                name.topAnchor.constraint(equalTo: avatar.bottomAnchor, constant: 10),
                name.centerXAnchor.constraint(equalTo: view.centerXAnchor)])
                
            NSLayoutConstraint.activate([
                portfolio.topAnchor.constraint(equalTo: name.bottomAnchor, constant: 4),
                portfolio.centerXAnchor.constraint(equalTo: view.centerXAnchor)])
                
            NSLayoutConstraint.activate([
                yearTitle.topAnchor.constraint(equalTo: portfolio.bottomAnchor, constant: 15),
                yearTitle.centerXAnchor.constraint(equalTo: avatar.leadingAnchor)])
                
                
            NSLayoutConstraint.activate([
                year.topAnchor.constraint(equalTo: yearTitle.bottomAnchor, constant: 10),
                year.leadingAnchor.constraint(equalTo: yearTitle.leadingAnchor),
                year.widthAnchor.constraint(equalToConstant: 275),
                year.heightAnchor.constraint(equalToConstant: 50)])
                
            NSLayoutConstraint.activate([
                displayAbout.topAnchor.constraint(equalTo: year.bottomAnchor, constant: 10),
                displayAbout.leadingAnchor.constraint(equalTo: year.leadingAnchor)])
                
            NSLayoutConstraint.activate([
                about.topAnchor.constraint(equalTo: displayAbout.bottomAnchor, constant: 7),
                about.leadingAnchor.constraint(equalTo: displayAbout.leadingAnchor),
                about.widthAnchor.constraint(equalToConstant: 275),
                about.heightAnchor.constraint(equalToConstant: 200)])
                
            NSLayoutConstraint.activate([
                editProfile.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: 17),
                editProfile.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                editProfile.widthAnchor.constraint(equalToConstant: 200),
                editProfile.heightAnchor.constraint(equalToConstant: 50)])
        }
        
//        NSLayoutConstraint.activate([
//                            name.topAnchor.constraint(equalTo: view.topAnchor),
//                            name.bottomAnchor.constraint(equalTo: view.bottomAnchor),
//                            name.leadingAnchor.constraint(equalTo: view.leadingAnchor),
//                            name.trailingAnchor.constraint(equalTo: view.trailingAnchor)])
        
        
        func updateSave(nameVal: String?, aboutVal: String?, portfolioVal: String?, yearVal : String?){
            if let n = nameVal{
                self.name.text = n
                updateName(nameV: n)
            }
//            else{showAlert()}
            if let y = yearVal{
                self.year.text = y
                //updateYear(yearV: y)
            }
            if let a = aboutVal{
                updateAbout(aboutV : a)
            }
            if let p = portfolioVal{
                updatePortfolio(portfolioV : p)
            }
           
        }
    
    @objc func picPressed (){
//        navigationController?.pushViewController(ProfileImageController(), animated: true)
        presentPic()
        //send to delegator??
    }
    
    func updatePic (filename : String?){
        if let item = filename{
            avatar.setImage(UIImage(named: item), for: .normal)
            view.addSubview(avatar)
        }
    }
    
    @objc func profilePressed(){
        let editor = EditController()
        editor.parentController? = self
        navigationController?.pushViewController(editor, animated: true)
        //profileIndex = profileIndex+1
        //presentProfile()
    }
    
//    @objc func presentProfile(){
//        let editor = EditController()
//        editor.parentController? = self
//        present(editor, animated: true, completion : nil)
//    }
    
    @objc func presentPic(){
        let editor = ProfileImageController()
        editor.parentController? = self
        present(editor, animated: true, completion : nil)
    }
        
        func updateName(nameV : String){
            name.text = nameV
            view.addSubview(name)
        }
        
        func updateAbout(aboutV : String){
                about.text = aboutV
        
        }
        func updateYear(yearV : String){
            year.text = yearV
        }
        
        func updatePortfolio(portfolioV : String){
            portfolio.text = portfolioV
            
        }
      
        // Do any additional setup after loading the view.

        
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
