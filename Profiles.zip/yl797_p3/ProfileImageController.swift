//
//  ProfileImageController.swift
//  yl797_p3
//
//  Created by Joanna Lin on 3/16/22.
//

import UIKit

class ProfileImageController: UIViewController {

    var chosen = UIImageView ()
   
        
    
    var avatar1 = UIButton ()
    var avatar2 = UIButton ()
    var avatar3 = UIButton ()
    var avatar4 = UIButton ()
    var avatar5 = UIButton ()
    var avatar6 = UIButton ()
    var parentController: MainController?
    var index=0

    convenience init (index: Int){
        self.init()
        self.index = index
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       view.backgroundColor = .white
        
        if (self.index==0){
            chosen.image = UIImage(named:"Image")}
        chosen.contentMode = .scaleAspectFill
        chosen.clipsToBounds = true
        chosen.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(chosen)
        
        avatar1.setImage(UIImage(named:"Image"), for: .normal)
        avatar1.addTarget(self, action: #selector(toThisPic1), for: .touchUpInside)
        avatar1.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(avatar1)
        
        avatar2.setImage(UIImage(named:"Image-2"), for: .normal)
        avatar2.addTarget(self, action: #selector(toThisPic2), for: .touchUpInside)
        avatar2.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(avatar2)
        
        avatar3.setImage(UIImage(named:"Image-3"), for: .normal)
        avatar3.addTarget(self, action: #selector(toThisPic3), for: .touchUpInside)
        avatar3.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(avatar3)
        
        
        avatar4.setImage(UIImage(named:"Image-4"), for: .normal)
        avatar4.addTarget(self, action: #selector(toThisPic4), for: .touchUpInside)
        avatar4.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(avatar4)
        
        avatar5.setImage(UIImage(named:"Image-5"), for: .normal)
        avatar5.addTarget(self, action: #selector(to5), for: .touchUpInside)
        avatar5.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(avatar5)
        
        avatar6.setImage(UIImage(named:"Image-1"), for: .normal)
        avatar6.addTarget(self, action: #selector(toThis6), for: .touchUpInside)
        avatar6.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(avatar6)
        

            setupConstraint()
        }
        // Do any additional setup after loading the view.
    
    
    
    @objc func toThisPic1(){
        chosen.image = UIImage(named:"Image")
        parentController?.updatePic(filename: "Image")
        dismiss(animated: true, completion: nil)

    }
    
    @objc func toThisPic2(){
        chosen.image = UIImage(named:"Image-2")
        parentController?.updatePic(filename: "Image-2")
        dismiss(animated: true, completion: nil)

    }
    
    @objc func toThisPic3(){
        chosen.image = UIImage(named:"Image-3")
        parentController?.updatePic(filename: "Image-3")
        dismiss(animated: true, completion: nil)

    }
    
    @objc func toThisPic4(){
        chosen.image = UIImage(named:"Image-4")
        parentController?.updatePic(filename: "Image-4")
        dismiss(animated: true, completion: nil)

    }
    
    @objc func to5(){
        chosen.image = UIImage(named:"Image-5")
        parentController?.updatePic(filename: "Image-5")
        dismiss(animated: true, completion: nil)

    }
    
    @objc func toThis6(){
        chosen.image = UIImage(named:"Image-1")
        parentController?.avatar.setImage(UIImage(named:"Image-1"), for: .normal)
        dismiss(animated: true, completion: nil)

    }

func setupConstraint(){
    NSLayoutConstraint.activate([
        chosen.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
        chosen.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        chosen.widthAnchor.constraint(equalToConstant: 200),
        chosen.heightAnchor.constraint(equalToConstant: 200),
        avatar1.topAnchor.constraint(equalTo: chosen.bottomAnchor, constant: 25),
        avatar1.centerXAnchor.constraint(equalTo: chosen.leadingAnchor),
        avatar1.widthAnchor.constraint(equalToConstant: 150),
        avatar1.heightAnchor.constraint(equalToConstant: 150),
        avatar2.topAnchor.constraint(equalTo: chosen.bottomAnchor, constant: 25),
        avatar2.centerXAnchor.constraint(equalTo: chosen.trailingAnchor),
        avatar2.widthAnchor.constraint(equalToConstant: 150),
        avatar2.heightAnchor.constraint(equalToConstant: 150),
        avatar3.topAnchor.constraint(equalTo: avatar1.bottomAnchor, constant: 15),
        avatar3.centerXAnchor.constraint(equalTo: chosen.leadingAnchor),
        avatar3.widthAnchor.constraint(equalToConstant: 150),
        avatar3.heightAnchor.constraint(equalToConstant: 150),
        avatar4.topAnchor.constraint(equalTo: avatar2.bottomAnchor, constant: 15),
        avatar4.centerXAnchor.constraint(equalTo: chosen.trailingAnchor),
        avatar4.widthAnchor.constraint(equalToConstant: 150),
        avatar4.heightAnchor.constraint(equalToConstant: 150),
        avatar5.topAnchor.constraint(equalTo: avatar3.bottomAnchor, constant: 15),
        avatar5.centerXAnchor.constraint(equalTo: avatar1.centerXAnchor),
        avatar5.widthAnchor.constraint(equalToConstant: 150),
        avatar5.heightAnchor.constraint(equalToConstant: 150),
        avatar6.topAnchor.constraint(equalTo: avatar4.bottomAnchor, constant: 15),
        avatar6.centerXAnchor.constraint(equalTo: avatar2.centerXAnchor),
        avatar6.widthAnchor.constraint(equalToConstant: 150),
        avatar6.heightAnchor.constraint(equalToConstant: 150),
        
    ])
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
