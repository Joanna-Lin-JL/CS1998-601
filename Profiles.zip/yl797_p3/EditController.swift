//
//  EditController.swift
//  yl797_p3
//
//  Created by Joanna Lin on 3/16/22.
//

import UIKit

class EditController: UIViewController {
    //change the tv to loop + list
    let editPorfileField = UILabel ()
    let nameTitle = UILabel ()
    let aboutTitle = UILabel ()
    let yearTitle = UILabel ()
    let portfolioTitle = UILabel ()
    var nameField = UITextField ()
    var portfolioField = UITextField ()
    var aboutField = UITextField ()
    var yearField = UITextField ()
    var backButton = UIButton ()
    var saveButton = UIButton ()
    var parentController: MainController?
    var index = 0
    
    convenience init(index: Int){
        self.init()
        self.index = index
    }
    
    override func viewDidLoad() {
        if index == 0{
        super.viewDidLoad()
        view.backgroundColor = .white
        
        editPorfileField.text = "Edit Porfile"
        editPorfileField.textColor = .brown
        editPorfileField.font = .systemFont(ofSize: 20, weight: .semibold)
        editPorfileField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(editPorfileField)
        
        nameTitle.text = "Name"
        nameTitle.textColor = .brown
        nameTitle.font = .systemFont(ofSize: 20, weight: .semibold)
        nameTitle.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(nameTitle)
        
        aboutTitle.text = "About"
        aboutTitle.textColor = .brown
        aboutTitle.font = .systemFont(ofSize: 20, weight: .semibold)
        aboutTitle.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(aboutTitle)
        
        yearTitle.text = "Year"
        yearTitle.textColor = .brown
        yearTitle.font = .systemFont(ofSize: 20, weight: .semibold)
        yearTitle.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(yearTitle)
        
        portfolioTitle.text = "Porfolio"
        portfolioTitle.textColor = .brown
        portfolioTitle.font = .systemFont(ofSize: 20, weight: .semibold)
        portfolioTitle.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(portfolioTitle)
        
        nameField.placeholder = "Insert Name"
        nameField.layer.cornerRadius = 10
        nameField.textColor = .black
        nameField.font = .systemFont(ofSize: 15)
        nameField.backgroundColor = UIColor(red: 0.93, green: 0.79, blue: 0.69, alpha: 1.0)
        nameField.adjustsFontSizeToFitWidth = true
        nameField.layer.cornerRadius = 10
        nameField.textAlignment = .justified
        nameField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(nameField)
        
        portfolioField.placeholder = "Insert Portfolio"
        portfolioField.layer.cornerRadius = 10
        portfolioField.textColor = .black
        portfolioField.font = .systemFont(ofSize: 15)
        portfolioField.backgroundColor = UIColor(red: 0.93, green: 0.79, blue: 0.69, alpha: 1.0)
        portfolioField.adjustsFontSizeToFitWidth = true
        portfolioField.layer.cornerRadius = 10
        portfolioField.textAlignment = .justified
        portfolioField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(portfolioField)
        
        aboutField.placeholder = "Insert About"
        aboutField.layer.cornerRadius = 10
        aboutField.textColor = .black
        aboutField.font = .systemFont(ofSize: 15)
        aboutField.backgroundColor = UIColor(red: 0.93, green: 0.79, blue: 0.69, alpha: 1.0)
        aboutField.adjustsFontSizeToFitWidth = true
        aboutField.layer.cornerRadius = 10
        aboutField.textAlignment = .justified
        aboutField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(aboutField)
        
        yearField.placeholder = "Insert Year"
        yearField.layer.cornerRadius = 10
        yearField.textColor = .black
        yearField.font = .systemFont(ofSize: 15)
        yearField.backgroundColor = UIColor(red: 0.93, green: 0.79, blue: 0.69, alpha: 1.0)
        yearField.adjustsFontSizeToFitWidth = true
        yearField.layer.cornerRadius = 10
        yearField.textAlignment = .justified
        yearField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(yearField)
        
        backButton.setTitle("Back", for: .normal)
        backButton.addTarget(self, action: #selector(backPressed), for: .touchUpInside)
        backButton.setTitleColor(.brown, for: .normal)
        backButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(backButton)
        
        saveButton.setTitle("Save", for: .normal)
        saveButton.addTarget(self, action: #selector(savePressed), for: .touchUpInside)
        saveButton.setTitleColor(.brown, for: .normal)
        saveButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(saveButton)
        
        setupConstraints()
            
        }
        // Do any additional setup after loading the view.
    }
    
    func setupConstraints(){
        NSLayoutConstraint.activate([
            editPorfileField.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 15),
        editPorfileField.centerXAnchor.constraint(equalTo: view.centerXAnchor)])
        
        NSLayoutConstraint.activate([
        nameField.topAnchor.constraint(equalTo: editPorfileField.bottomAnchor, constant: 55),
        nameField.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        nameField.widthAnchor.constraint(equalToConstant: 250),
        nameField.heightAnchor.constraint(equalToConstant: 50)])
        
        NSLayoutConstraint.activate([
        nameTitle.topAnchor.constraint(equalTo: editPorfileField.bottomAnchor, constant: 30),
        nameTitle.leadingAnchor.constraint(equalTo: nameField.leadingAnchor)])
        
        NSLayoutConstraint.activate([
        portfolioTitle.topAnchor.constraint(equalTo: nameField.bottomAnchor, constant: 15),
        portfolioTitle.leadingAnchor.constraint(equalTo: nameField.leadingAnchor)])
        
        NSLayoutConstraint.activate([
        portfolioField.topAnchor.constraint(equalTo: portfolioTitle.bottomAnchor, constant: 5),
        portfolioField.leadingAnchor.constraint(equalTo: nameField.leadingAnchor),
        portfolioField.widthAnchor.constraint(equalToConstant: 250),
        portfolioField.heightAnchor.constraint(equalToConstant: 50)])
        
        NSLayoutConstraint.activate([
        yearTitle.topAnchor.constraint(equalTo: portfolioField.bottomAnchor, constant: 15),
        yearTitle.leadingAnchor.constraint(equalTo: nameField.leadingAnchor)])
        
        NSLayoutConstraint.activate([
        yearField.topAnchor.constraint(equalTo: yearTitle.bottomAnchor, constant: 5),
        yearField.leadingAnchor.constraint(equalTo: nameField.leadingAnchor),
        yearField.widthAnchor.constraint(equalToConstant: 250),
        yearField.heightAnchor.constraint(equalToConstant: 50)])
       
        NSLayoutConstraint.activate([
        aboutTitle.topAnchor.constraint(equalTo: yearField.bottomAnchor, constant: 15),
        aboutTitle.leadingAnchor.constraint(equalTo: nameField.leadingAnchor)])
        
        NSLayoutConstraint.activate([
        aboutField.topAnchor.constraint(equalTo: aboutTitle.bottomAnchor, constant: 5),
        aboutField.leadingAnchor.constraint(equalTo: nameField.leadingAnchor),
        aboutField.widthAnchor.constraint(equalToConstant: 250),
        aboutField.heightAnchor.constraint(equalToConstant: 100)])
        
        NSLayoutConstraint.activate([
        backButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant:15),
        backButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 15),
        backButton.widthAnchor.constraint(equalToConstant: 60),
        backButton.heightAnchor.constraint(equalToConstant: 30)])
        
        NSLayoutConstraint.activate([
        saveButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant:15),
        saveButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -15),
        saveButton.widthAnchor.constraint(equalToConstant: 60),
        saveButton.heightAnchor.constraint(equalToConstant: 30)
        ])
    }
    
    @objc func savePressed(){
        
        //        let item: String? = inputItem.text
        if let name = nameField.text, !name.isEmpty{
            parentController?.name.text = name
        }
        else{
            showAlert()
        }
        if let ab = aboutField.text{
            parentController?.about.text = ab
        }
        if let por = portfolioField.text{
            parentController?.portfolio.text = por
        }
        if let yr = yearField.text{
            parentController?.year.text = yr
        }
        
        parentController?.updateSave(nameVal: nameField.text, aboutVal: aboutField.text, portfolioVal: portfolioField.text, yearVal: yearField.text)
        navigationController?.popViewController(animated: true)
       //dismiss(animated: true, completion: nil)
        
    }
    
    
    
    func showAlert(){
        let alert = UIAlertController(title: "Invalid Name", message: "Name field is required", preferredStyle: .alert)
        alert.addTextField{ textField in
            textField.placeholder = "Insert Name"
        }
        let invalidate = { self.nameField.invalidate(placeHolder: "Insert Name")}
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel){
            _ in invalidate()
        })
        alert.addAction(UIAlertAction(title: "Update", style: .default){_ in guard let title = alert.textFields?[0].text, !title.isEmpty else{invalidate(); return}
            self.nameField.text = title
            self.savePressed()})
        present(alert, animated: true, completion: nil)
    }
    @objc func backPressed(){
        navigationController?.popViewController(animated: true)
//        dismiss(animated: true, completion: nil)
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension UITextField {
    
    func invalidate(placeHolder: String) {
        attributedPlaceholder = NSAttributedString(
            string: placeHolder,
            attributes: [.foregroundColor : UIColor.systemRed.withAlphaComponent(0.55) ]
        )
    }
    
}
