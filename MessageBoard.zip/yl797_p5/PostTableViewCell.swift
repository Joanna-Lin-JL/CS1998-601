//
//  PostTableViewCell.swift
//  yl797_p5
//
//  Created by Joanna Lin on 3/27/22.
//

import UIKit

class PostTableViewCell: UITableViewCell {

    static let id = "PostID"
    
    static let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "MM/DD/YY"
        return formatter
    }()
    
    var posttitle: UITextView = {
       let tv = UITextView()
        tv.isScrollEnabled = false
        tv.isEditable = false
        tv.textColor = .black
        tv.backgroundColor = .brown
        tv.font = .systemFont(ofSize: 25, weight: .bold)
        tv.isUserInteractionEnabled = false
        return tv
    }()
    
    var posttext: UITextView = {
        let tv = UITextView()
        tv.isScrollEnabled = false
        tv.isEditable = false
        tv.textColor = .black
        tv.backgroundColor = .brown
        tv.font = .systemFont(ofSize: 15)
        tv.isUserInteractionEnabled = false
        
//        tv.layer.cornerRadius = 10
//        tv.layer.borderWidth = 5
//        tv.layer.borderColor = 
        
        return tv
    }()
    
//    var editpostbutton: UIButton = {
//        let button = UIButton()
//        return button
//    }()
    
    var timestamp: UILabel = {
       let label = UILabel()
        label.textAlignment = .left
        label.textColor = .black
        label.text = "5/5/55"
        label.font = .systemFont(ofSize: 10)
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
            super.init(style: style, reuseIdentifier: reuseIdentifier)
            backgroundColor = .brown
            selectionStyle = .none
            
            
            [posttitle, posttext, timestamp].forEach { subView in
                subView.translatesAutoresizingMaskIntoConstraints = false
                contentView.addSubview(subView)
            }
            
            NSLayoutConstraint.activate([
                posttitle.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 5),
                posttitle.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
                posttitle.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 5),
                posttitle.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -5),
                
                
                posttext.topAnchor.constraint(equalTo: posttitle.bottomAnchor, constant: 5),
                posttext.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
//                posttext.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
                posttext.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 5),
                posttext.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -5),
                
                timestamp.topAnchor.constraint(equalTo: posttext.bottomAnchor, constant: 15),
                timestamp.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -10),
                timestamp.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -10),
                timestamp.heightAnchor.constraint(equalToConstant: 20)
                
                
            ])
        }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func configure(post: Post){
        if let ptext = post.posttext {
            posttext.text = ptext
        }
        else{
            posttext.text = "Nothing"
        }

//        posttext.text = post.posttext
        posttitle.text = post.title
        if let date = post.timestamp {
            timestamp.text = PostTableViewCell.dateFormatter.string(from: date)
        }
        
    }
    
    
    
    
    
}
