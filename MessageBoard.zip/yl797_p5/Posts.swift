//
//  Posts.swift
//  yl797_p5
//
//  Created by Joanna Lin on 3/27/22.
//

import Foundation

struct Post: Codable {
    var id: UUID? = nil
    var posttext: String? = nil
    var timestamp: Date? = nil
    var poster: String? = nil
    var title: String? = nil
}
