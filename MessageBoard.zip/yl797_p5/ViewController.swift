//
//  ViewController.swift
//  yl797_p5
//
//  Created by Joanna Lin on 3/27/22.
//

import UIKit

protocol VCProtocol{
    func viewDidLoad()
    func setupConstraints()
    func update(posttext: String, titletext: String)
    func postpressed()
    //TODO: add all the functions
}

class ViewController: UIViewController, VCProtocol {
    
    let reuseIdentifier = "PostCellReuse"
    var chosen = -1
    
    var posts: [Post] = [] {
        didSet {
            postview.reloadData()
//            nopost.isHidden = posts.count != 0
        }
    }
    
    lazy var postview: UITableView = {
        let tableView = UITableView()
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(PostTableViewCell.self, forCellReuseIdentifier: PostTableViewCell.id)
        tableView.estimatedRowHeight = 200
        tableView.isScrollEnabled = true
        return tableView
    }()
    
//    let nopost: UILabel = {
//        let label = UILabel()
//        label.text = "No post"
//        label.isHidden = true
//        label.textAlignment = .center
//        label.adjustsFontSizeToFitWidth = true
//        return label
//    }()
    
    let postfield: UITextView = {
        let tv = UITextView()
        tv.textColor = .black
        tv.isEditable = true
        tv.backgroundColor = .lightGray
        tv.textAlignment = .justified
        tv.layer.cornerRadius = 10
        tv.font = .systemFont(ofSize: 15)
        return tv
    }()
    
    let postbutton: UIButton = {
        let button = UIButton ()
        button.backgroundColor = .blue
        button.addTarget(self, action: #selector(postpressed), for: .touchUpInside)
        button.setTitle("Post", for: .normal)
        button.layer.cornerRadius = 10
        return button
    }()
    
    let titlefield: UITextField = {
       let tf = UITextField()
        tf.font = .systemFont(ofSize: 20, weight: .semibold)
        tf.backgroundColor = .lightGray
        tf.textAlignment = .justified
        tf.textColor = .black
        tf.placeholder = "Title"
        tf.layer.cornerRadius = 10
        return tf
    }()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .white
        self.title = "Message Board"
        
        [titlefield, postfield, postbutton, postview].forEach { subView in
            view.addSubview(subView)
            subView.translatesAutoresizingMaskIntoConstraints = false
        }
        
        
        
        setupConstraints()
        
        //Do any additional setup after loading the view.
    }
    
    
    func setupConstraints(){
        NSLayoutConstraint.activate([
            titlefield.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 15),
            titlefield.heightAnchor.constraint(equalToConstant: 50),
            titlefield.widthAnchor.constraint(equalToConstant: 350),
            titlefield.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 0),
            
            postfield.topAnchor.constraint(equalTo: titlefield.bottomAnchor, constant: 5),
            postfield.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            postfield.heightAnchor.constraint(equalToConstant: 100),
            postfield.widthAnchor.constraint(equalToConstant: 350),
            
            
            postbutton.trailingAnchor.constraint(equalTo: postfield.trailingAnchor),
            postbutton.topAnchor.constraint(equalTo: postfield.bottomAnchor, constant: 5),
            postbutton.widthAnchor.constraint(equalToConstant: 60),
            postbutton.heightAnchor.constraint(equalToConstant: 30),
            
            postview.topAnchor.constraint(equalTo: postbutton.bottomAnchor, constant: 10),
            postview.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            postview.widthAnchor.constraint(equalToConstant: 250),
            postview.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: 10)
        ])
        
        
    }
    
    @objc func postpressed(){
        //TODO: add the post to the table cell array
        posts.append(Post(posttext: postfield.text, title: titlefield.text))
        postfield.text = ""
        titlefield.text = ""
        postview.reloadData()
        
    }
    

    func update(posttext: String, titletext: String){
        posts[chosen].posttext = posttext
        posts[chosen].title = titletext
        postview.reloadData()
    }
}
    


    extension ViewController: UITableViewDataSource {
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return posts.count
        }
        
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            if let cell = tableView.dequeueReusableCell(withIdentifier: PostTableViewCell.id, for: indexPath) as? PostTableViewCell {
                
                let i = posts[indexPath.row]
                cell.configure(post: i)
                cell.selectionStyle = .none
                cell.layer.borderColor = CGColor.init(red: 255, green: 255, blue: 255, alpha: 1)
                cell.layer.borderWidth = 5
                cell.layer.cornerRadius = 10
                return cell
            } else {
                return UITableViewCell()
            }
        }
    }



    extension ViewController: UITableViewDelegate {
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            //return 150
            return UITableView.automaticDimension
        }
//
        func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
            return UITableView.automaticDimension
        }
        
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let editor = EditPostView()
            editor.parentController = self
            editor.originalpost = posts[indexPath.item]
            chosen = indexPath.row
            present(editor, animated: true, completion: nil)
        }
        
//        func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
//            posts.remove(at: indexPath.row)
//            return UISwipeActionsConfiguration()
//        }
        
        func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
            if editingStyle == .delete {
                posts.remove(at: indexPath.row)
            }
        }
    }
    


