//
//  EditPostView.swift
//  yl797_p5
//
//  Created by Joanna Lin on 4/2/22.
//

import UIKit

class EditPostView: UIViewController {

    var parentController: VCProtocol?
    
    
    var originalpost: Post?{
        didSet{
            titlefield.text = originalpost?.title
            postfield.text = originalpost?.posttext
            poster.text = originalpost?.poster
            //TODO: all the variables are set
        }
    }
    
    
    var editpost: UILabel = {
        let label = UILabel()
        label.font = .boldSystemFont(ofSize: 20)
        label.text = "Edit Post"
        return label
    }()
    
    var titlefield: UITextView = {
       let tv = UITextView()
        tv.textColor = .black
        tv.isEditable = true
        tv.font = .systemFont(ofSize: 25, weight: .semibold)
        tv.isScrollEnabled = true
        tv.layer.cornerRadius = 10
        tv.backgroundColor = .lightGray
        return tv
    }()
    
    var poster: UILabel = {
       let label = UILabel()
        label.font = .boldSystemFont(ofSize: 10)
        return label
    }()
    
    var updatebutton: UIButton = {
       let button = UIButton()
        button.backgroundColor = .blue
        button.addTarget(self, action: #selector(updatepressed), for: .touchUpInside)
        button.setTitle("Update", for: .normal)
        button.layer.cornerRadius = 10
        return button
    }()
    
    var postfield: UITextView = {
        let tv = UITextView()
        tv.textColor = .black
        tv.textAlignment = .justified
        tv.layer.cornerRadius = 10
        tv.font = .systemFont(ofSize: 15)
        tv.backgroundColor = .lightGray
        return tv
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        self.title = "Edit Post"

        [updatebutton, postfield, poster, editpost, titlefield] .forEach { subView in
            view.addSubview(subView)
            subView.translatesAutoresizingMaskIntoConstraints = false
        }
        
        setUpUpdateConstraints()
        // Do any additional setup after loading the view.
    }
    
    func setUpUpdateConstraints(){
        NSLayoutConstraint.activate([
            
            editpost.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 15),
            editpost.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 15),
            
            titlefield.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 60),
            titlefield.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            titlefield.heightAnchor.constraint(equalToConstant: 100),
            titlefield.widthAnchor.constraint(equalToConstant: 350),
            
            postfield.topAnchor.constraint(equalTo: titlefield.bottomAnchor, constant: 10),
            postfield.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            postfield.heightAnchor.constraint(equalToConstant: 500),
            postfield.widthAnchor.constraint(equalToConstant: 350),
            
            updatebutton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -15),
            updatebutton.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -15),
            updatebutton.widthAnchor.constraint(equalToConstant: 80),
            updatebutton.heightAnchor.constraint(equalToConstant: 40)
        
        ])
    }
    
    @objc func updatepressed(){
        parentController?.update(posttext: postfield.text, titletext: titlefield.text)
        dismiss(animated: true, completion: nil)
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
